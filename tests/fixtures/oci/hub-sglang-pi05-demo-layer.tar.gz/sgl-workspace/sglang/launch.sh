#!/bin/bash
# oci-layer-demo launch.sh
exec python3 -m sglang.launch_server "$@"
